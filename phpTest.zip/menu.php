<!--
AUTHOR : AMANI A. SAINT-CLAIR
EMAIL : aymeric@zgamesoft.com
The menu script
-->

<?php
?>

<div class="topnav" id="myTopnav">
  <a href="index.php">Home</a>
  <a href="login.php">Login</a>
  <a href="signup.php">Sign Up</a>
  <a href="about.php">About</a>
  <a href="javascript:void(0);" class="icon" onclick="myFunction()">
    <i class="fa fa-bars"></i>
  </a>
</div>

<?php
?>
