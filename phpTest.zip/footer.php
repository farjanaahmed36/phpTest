<!--
AUTHOR : AMANI A. SAINT-CLAIR
EMAIL : aymeric@zgamesoft.com
footer script here are informations
on the bottom of all the pages
-->

<?php
?>
<div class="footer">
  <p>
    By AMANI A. SAINT-CLAIR <BR>
Email : aymeric@zgamesoft.com
  </p>
</div>
<?php

?>
